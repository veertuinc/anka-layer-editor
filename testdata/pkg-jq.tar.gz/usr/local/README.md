jq layer readme - intentionally longer for size mismatch
