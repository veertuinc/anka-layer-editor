brew formula: jq
