brew formula: wireguard-tools
