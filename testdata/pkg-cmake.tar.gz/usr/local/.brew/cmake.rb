brew formula: cmake
