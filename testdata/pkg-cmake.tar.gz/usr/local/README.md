CMake layer readme
